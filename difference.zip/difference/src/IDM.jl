#updated

struct IDMParam <: FieldVector{6, Float64} 
	a::Float64 
	b::Float64 
	T::Float64 
	v0::Float64 
	s0::Float64 
	del::Float64 
end 

StaticArrays.similar_type(::Type{IDMParam}, ::Type{Float64}, ::Size{(6,)}) = IDMParam    #no

nan(::Type{IDMParam}) = IDMParam(NaN, NaN, NaN, NaN, NaN, NaN)


function get_idm_s_star(p::IDMParam, v::Float64, dv::Float64)   #no
    return p.s0 + max(0.,v*p.T+v*dv/(2*sqrt(p.a*p.b)))
end


function get_idm_dv(p::IDMParam,dt::Float64,v::Float64,dv::Float64,s::Float64)  #AS
	s_ = get_idm_s_star(p, v, dv)
    @assert p.del == 4.0
    dvdt = p.a*(1.-(v/p.v0)^4 - (s_/s)^2)  
	
	return (dvdt*dt)::Float64 
end 

# these aren't used anymore, but need to be there for the tests
IDMParam(a::Float64,b::Float64,T::Float64,v0::Float64,s0::Float64;del::Float64=4.) = IDMParam(a,b,T,v0,s0,del)
function build_cautious_idm(v0::Float64,s0::Float64)  #replaced by function IDMParam(s::AbstractString)
	T = 2.
	a = 1.
	b = 1.
	return IDMParam(a,b,T,v0,s0)
end

function build_aggressive_idm(v0::Float64,s0::Float64) #replaced by function IDMParam(s::AbstractString)
	T = 0.8
	a = 2.
	b = 2.
	return IDMParam(a,b,T,v0,s0)
end

function build_normal_idm(v0::Float64,s0::Float64) #replaced by function IDMParam(s::AbstractString)
	T = 1.4
	a = 1.5
	b = 1.5
	return IDMParam(a,b,T,v0,s0)
end

#TODO: use Enum or something to avoid misspelling errors
function IDMParam(s::AbstractString,v0::Float64,s0::Float64) #replaced by function IDMParam(s::AbstractString)
	if lowercase(s) == "cautious"
		return build_cautious_idm(v0,s0)
	elseif lowercase(s) == "normal"
		return build_normal_idm(v0,s0)
	elseif lowercase(s) == "aggressive"
		return build_aggressive_idm(v0,s0)
	else
		error("No such idm phenotype: \"$(s)\"")
	end
end
