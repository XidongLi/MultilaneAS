#ifndef PASSENGER_H
#define PASSENGER_H

#include<iostream>
#include<vector>
using namespace std;

class passenger
{
public:
    int ini_floor;
    int target_floor;
    int in_elevator;
    int elevator_number;
    int id;
    int boarding;
    int boarding_time;
    int alighting;
    int alighting_time;
    int processed;
    passenger(int n1, int n2, int n3);
};

#endif