#include <iostream>
#include "elevator.h"
using namespace std;

elevator::elevator(int n1, int max_floor){
	direction = 2;
    cur_floor = 1;
    id = n1;
    run_time = 0;
    alight_number = 0;
    for(int i=0;i<max_floor;i++){
        pushed.push_back(0);
        request.push_back(0);
    }

};

ele_system::ele_system(int a, int b, int c, int d, int e){
    x = a;
    y =b;
    m =c;
    n=d;
    z=e;
    for(int i = 1; i <= m; i++){
		elevators.push_back(elevator(i, n));
	}
}

void ele_system::add_passenger(passenger p){
    passengers.push_back(p);
}
int ele_system::get_last_id(){
    return passengers.back().id;
}


void ele_system::print(){
    for(int i=0;i<m;i++){
        cout<<"E"<<elevators[i].id<<" ";
        cout<<"F"<<elevators[i].cur_floor<<" ";
        if (elevators[i].direction==2){
            cout<<"S"<<" ";
        }
        else if (elevators[i].direction==1){
            cout<<"U"<<" ";
        }
        else if (elevators[i].direction==-1){
            cout<<"D"<<" ";
        }
        else {
            cout<<"O"<<" ";
        }
        for(int j=0;j<elevators[i].passengers.size();j++){
            if(elevators[i].passengers[j].in_elevator==1){
                cout<<"P"<<elevators[i].passengers[j].id<<" ";
            }
            
        }
        cout<<endl;
    }
    for(int i=1;i<=n;i++){
        cout<<"F"<<i<<" ";
        for(int j=0;j<passengers.size();j++){
            if ((passengers[j].in_elevator ==0)&&(passengers[j].ini_floor ==i)){
                cout<<"P"<<passengers[j].id<<" ";
            }
        }
        cout<<endl;
    }
    for(int i=0;i<passengers.size();i++){
        cout<<"P"<<passengers[i].id<<" ";
        if (passengers[i].in_elevator !=0){
            cout<<"E"<<passengers[i].elevator_number<<" ";
            if(passengers[i].target_floor == elevators[passengers[i].elevator_number-1].cur_floor){
                cout<<"F"<<passengers[i].target_floor<<" ";
            }
        }
        else 
        {
            cout<<"F"<<passengers[i].ini_floor<<" ";
            if(passengers[i].ini_floor == elevators[passengers[i].elevator_number-1].cur_floor){
                cout<<"E"<<passengers[i].elevator_number<<" ";
            }
        }
        cout<<endl;
    

    }   
}  
bool ele_system::terminate(){
    if (passengers.empty()){
        return true;
    }
}    

int elevator::d_run_direction(){
    for(int f=cur_floor-1;f>=1;f--){
        if(request[f-1]+pushed[f-1]==0){
            continue;
        }
        else{
            return -1;
        }
    }
    return 1;
}


void ele_system::p_passengers(){
    for(int p_i=0;p_i<passengers.size();p_i++){
        if(passengers[p_i].processed ==0){
            for(int e_i=0;e_i<passengers.size();e_i++){
                if (elevators[e_i].direction==2){
                    if (passengers[p_i].ini_floor==elevators[e_i].cur_floor){
                        elevators[e_i].direction=0;
                    }
                    else{
                        elevators[e_i].run_time = x;
                        if (passengers[p_i].ini_floor<elevators[e_i].cur_floor){
                            elevators[e_i].direction=-1;
                        }
                        else{
                            elevators[e_i].direction=1;
                        }
                    }
                    elevators[e_i].request[passengers[p_i].ini_floor-1]++;
                    passengers[p_i].elevator_number = e_i+1;
                    passengers[p_i].processed = 1;
                    elevators[e_i].passengers.push_back(passengers[p_i]);
                    break;
                } 
                if(1+elevators[e_i].passengers.size()-elevators[e_i].alight_number<=z){
                    if((passengers[p_i].target_floor>passengers[p_i].ini_floor) && (elevators[e_i].d_run_direction()==1)){
                        if((elevators[e_i].direction==0) && (passengers[p_i].ini_floor>=elevators[e_i].cur_floor)){}
                        else if(((elevators[e_i].direction==1)||(elevators[e_i].direction==-1)) && (passengers[p_i].ini_floor>elevators[e_i].cur_floor)){} 
                        else{continue;}
                        elevators[e_i].request[passengers[p_i].ini_floor-1]++;
                        passengers[p_i].elevator_number = e_i+1;
                        passengers[p_i].processed = 1;
                        elevators[e_i].passengers.push_back(passengers[p_i]);
                    }
                    else if((passengers[p_i].target_floor<passengers[p_i].ini_floor) && (elevators[e_i].d_run_direction()==-1)){
                        if((elevators[e_i].direction==0) && (passengers[p_i].ini_floor>=elevators[e_i].cur_floor)){}
                        else if(((elevators[e_i].direction==1)||(elevators[e_i].direction==-1)) && (passengers[p_i].ini_floor>elevators[e_i].cur_floor)){} 
                        else{continue;}
                        elevators[e_i].request[passengers[p_i].ini_floor-1]++;
                        passengers[p_i].elevator_number = e_i+1;
                        passengers[p_i].processed = 1;
                        elevators[e_i].passengers.push_back(passengers[p_i]);
                    }
                }
                
            }
        }
    }
}

void ele_system::process_elevators(){
    for(int e_i=0; e_i<m; e_i++){
        if(elevators[e_i].direction==0){
            bool change_direction = true;
            for(int p_i=0; p_i<elevators[e_i].passengers.size(); p_i++){
                int delete_index = 0;
                if((elevators[e_i].passengers[p_i].boarding ==0) &&(elevators[e_i].passengers[p_i].ini_floor==elevators[e_i].cur_floor) &&(elevators[e_i].passengers[p_i].in_elevator==0)){
                    elevators[e_i].passengers[p_i].boarding = 1;
                    elevators[e_i].passengers[p_i].boarding_time = y;
                    elevators[e_i].pushed[elevators[e_i].passengers[p_i].target_floor-1]++;
                }
                else if((elevators[e_i].passengers[p_i].alighting ==0) &&(elevators[e_i].passengers[p_i].target_floor==elevators[e_i].cur_floor)){
                    elevators[e_i].passengers[p_i].alighting = 1;
                    elevators[e_i].passengers[p_i].alighting_time = y;
                    elevators[e_i].alight_number++;
                }
                if(elevators[e_i].passengers[p_i].boarding ==1){
                    elevators[e_i].passengers[p_i].boarding_time--;
                    if(elevators[e_i].passengers[p_i].boarding_time==0){
                        elevators[e_i].passengers[p_i].in_elevator = 1;
                        elevators[e_i].passengers[p_i].boarding = 0;
                        elevators[e_i].request[elevators[e_i].cur_floor-1]--;
                    }
                    else{
                        change_direction = false;
                    }
                }
                if(elevators[e_i].passengers[p_i].alighting ==1){
                    elevators[e_i].passengers[p_i].alighting_time--;
                    if(elevators[e_i].passengers[p_i].alighting_time==0){
                        delete_index = elevators[e_i].passengers[p_i].id;
                        elevators[e_i].alight_number--;
                        elevators[e_i].pushed[elevators[e_i].passengers[p_i].target_floor-1]++;
                        elevators[e_i].passengers.erase(elevators[e_i].passengers.begin()+p_i);
                        p_i--;
                    }
                    else{
                        change_direction = false;
                    }
                }
                if (delete_index==0){
                    for(int k=0;k<passengers.size();k++){
                        if(passengers[k].id==elevators[e_i].passengers[p_i].id){
                            passengers[k]=elevators[e_i].passengers[p_i];
                            break;
                        }
                    }
                }
                else{
                    for(vector<passenger>::iterator iter = passengers.begin(); iter != passengers.end();iter++){
                        if ((*iter).id == delete_index){
                            passengers.erase(iter);
                            break;
                        }
                    }
                }
            }
            if(change_direction){
                elevators[e_i].run_time = x;
                elevators[e_i].direction = elevators[e_i].d_run_direction();
            }
            
        }
        
        else{
            elevators[e_i].run_time--;
            if(elevators[e_i].run_time==0){
                elevators[e_i].cur_floor += elevators[e_i].direction;
                if(elevators[e_i].request[elevators[e_i].cur_floor-1] + elevators[e_i].pushed[elevators[e_i].cur_floor-1] !=0){
                    elevators[e_i].direction=0;
                }
                else if(!elevators[e_i].passengers.empty()){
                    elevators[e_i].run_time = x;
                    elevators[e_i].direction = elevators[e_i].d_run_direction();
                }
            }
        }
        if(elevators[e_i].passengers.empty()){
            elevators[e_i].direction=2;
        }

    }
}

/*

处理电梯
for 电梯 in 电梯s：
    if 电梯.方向 == 0：
        电梯需要状态转变 == true
        for 顾客 in 电梯.顾客s：
            delete_index = 0 
            顾客开始上/下电梯（）
            if 顾客.boarding ==0 且 顾客.initial == 电梯.cur 且不再电梯中：
                顾客.boarding——time = y
                顾客.boarding =1
                E.pushed[顾客.target]++
            
            else if 顾客.alighting ==0 且 顾客.target == 电梯.cur ：
                顾客.alighting_time = y
                顾客.alighting = 1
                E.alihting_number++

            if 顾客正在上电梯：
                时间--
                if时间为0（完成上电梯）
                    顾客.in_elevator = 1
                    顾客.boarding =0
                    E.request[cur]--
                else
                    电梯需要状态转变 = false
            if 顾客正在下电梯：
                时间--
                if时间为0（完成下电梯）
                    delete_index = 顾客.id
                    删除顾客
                    E.pushed[顾客.target]--
                    E.alihting_number--
                    
                else
                    电梯需要状态转变 = false
            总顾客 = E.顾客
        if(电梯需要状态转变):
            E.running time = x
            电梯.方向 = 获取方向
    else if(E.passengers is empty and e.requests are all zero):
        E.direction = 2
    else：
        E.running time--
        if E.running time==0:
            E.cur_f += direction
            if E.request[cur] or E.pushed[cur] !=0:
                E.direction = 0
*/
//处理顾客
/*
if 方向==2：
    if 楼层相同：
        E。方向=0
    else：
        E。方向= 1/-1
        E.running_time = x
    E。request更新
    P。elevator——number
    precessed = 1
    E。P。push
    break；

if 人数满足（1+E.P.size()-E.alight_number<=max）:
    if P.target > P.initial 且 电梯方向 ==1：
        if 方向==0 and P.initial >= E.cur:
                
        else if 方向==1/-1 and P.initial > E.cur:

        else：
            continue；
        E。request更新
        P.电梯号
        P。processed
        E。P。push
    else if P.target < P.initial 且 电梯方向 == -1：
        if 方向==0 and P.initial >= E.cur:
            
                
        else if 方向==1/-1 and P.initial > E.cur:
            
        else：
            continue；
        E。request更新
        P.电梯号
        P。processed
        E。P。push
    
函数 电梯方向：（不考虑电梯内没人，也没人boarding）
    for 楼层=电梯楼层-1， 楼层>=1， 楼层--：
        if request【楼层-1】 和 pushed【楼层-1】 均为0：
            continue
        else
            return -1
    return 1
} 
*/
