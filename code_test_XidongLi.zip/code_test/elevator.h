#ifndef ELEVATOR_H
#define ELEVATOR_H

#include<iostream>
#include<vector>
#include "passenger.h"
using namespace std;

class elevator
{
public:
    elevator(int n1, int max_floor);
    int direction;//1:Up，-1:Down,0:Open, 2:Stop
    int cur_floor;  
    vector<int> pushed;
    vector<int> request;
    int id;
    int run_time;
    
    int alight_number;
    vector<passenger> passengers;
    int d_run_direction();
   
};

class ele_system
{
public:
    ele_system(int x, int y, int m, int n, int z);
    int x;
    int y;
    int m;
    int n;
    int z;
    vector<elevator> elevators;
    vector<passenger> passengers;
    void p_passengers();
    void print();
    bool terminate();
    void process_elevators();
    void add_passenger(passenger p);
    int get_last_id();
    
};

#endif