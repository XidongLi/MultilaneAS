#include <iostream>
#include "passenger.h"
using namespace std;


passenger::passenger(int n1, int n2, int n3){
	ini_floor = n1;
    target_floor = n2;
    in_elevator = 0;
    elevator_number = 0;
    id = n3;
    boarding = 0;
    boarding_time = 0;
    alighting = 0;
    alighting_time = 0;
    processed = 0;
};





/*

int get_ini_floor();
    int get_target_floor();
    int get_in_elevator();
    int get_elevator_number();
    int get_id();

    void set_in_elevator(int in);//1在，0不在
    void set_elevator_number(int number);

int passenger::get_ini_floor(){
    return ini_floor;
};

int passenger::get_target_floor(){
    return target_floor;
};

int passenger::get_in_elevator(){
    return in_elevator;
};

int passenger::get_elevator_number(){
    return elevator_number;
};

int passenger::get_id(){
    return id;
};

void passenger::set_in_elevator(int in){
    in_elevator = in;
};

void passenger::set_elevator_number(int number){
    elevator_number = number;
};
*/