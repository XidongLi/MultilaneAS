#include <iostream>
#include "passenger.cpp"
#include "elevator.cpp"
#include <string>

using namespace std;

int main(){
    int n, m, x, y, z;
    cin >> n>> m>> x>> y>> z;
    cin.get();
    ele_system sys = ele_system(x, y, m ,n, z);
    int t = 0;
    int b=0;
    int k =0;
    string in;
    bool done = true;
    bool get_input = true;
    while (done){
        if (get_input){
            
            getline(cin, in);
            if (in=="EOF"){
                get_input = false;
            }
            else{
                int start = 0;
                for(int end =1;end<=in.size();end++)
                if((in[end]==' ')||(end==in.size())){
                    if(b==0){
                        b = stoi(in.substr(start, end));
                        
                    }
                    else{
                        k = stoi(in.substr(start, end));
                    }
                    start = end+1;
                    end++;
                    if ((b!=0)&&(k!=0)){
                        if (sys.passengers.empty()){
                            sys.add_passenger(passenger(b, k, 1));
                        }
                        else{
                            sys.add_passenger(passenger(b, k, sys.get_last_id()+1));
                        }
                        b =0;
                        k =0;
                    }
                    
                }
            }
        }
        sys.p_passengers();
        sys.print();
        sys.process_elevators();
        t++;
        if (sys.terminate()){
            sys.print();
            cout<<"EOF"<<endl;
            done = false;
        }

    }

	return 0;
}